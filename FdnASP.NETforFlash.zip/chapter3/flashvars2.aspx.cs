using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class flashvars2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// button 1
		EpicFlashControl1.FlashVars.Add("title1", "Microsoft");
		EpicFlashControl1.FlashVars.Add("nav1", "http://www.microsoft.com");
		// button 2
		EpicFlashControl1.FlashVars.Add("title2", "Macromedia");
		EpicFlashControl1.FlashVars.Add("nav2", "http://www.macromedia.com");
		// button 3 
		EpicFlashControl1.FlashVars.Add("title3", "Friend's of Ed");
		EpicFlashControl1.FlashVars.Add("nav3", "http://www.friendsofed.com");
		// button 4
		EpicFlashControl1.FlashVars.Add("title4", "ASP.NET");
		EpicFlashControl1.FlashVars.Add("nav4", "http://www.asp.net");
		// button 5
		EpicFlashControl1.FlashVars.Add("title5", "epicFlashControl");
		EpicFlashControl1.FlashVars.Add("nav5", "http://www.epicsoft.net/products/flashnet/");
		// button 6
		EpicFlashControl1.FlashVars.Add("title6", "Visual Studio .NET");
		EpicFlashControl1.FlashVars.Add("nav6", "");
    }
}
