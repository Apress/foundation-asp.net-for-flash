using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data.OleDb;
using System.Data;


/// <summary>
/// Summary description for Service
/// </summary>
[WebService(Namespace = "http://www.friendsofed.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService {

    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    public struct Customer
    {
        public string CustomerId;
        public string CompanyName;
        public string ContactName;
        public string ContactTitle;
        public string Address;
        public string City;
        public string Country;
    }
    [WebMethod]
    public Customer[] GetCustomersDataSet()
    {
        OleDbConnection conn = new OleDbConnection();
        // change this to the location of your Northwind database
        conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\foundationaspnet\chapter8\Data\Northwind.mdb";

        // create a command object
        OleDbCommand cmd = new OleDbCommand();
        cmd.CommandText = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Country FROM Customers";
        cmd.Connection = conn;

        // create a new DataAdapter
        OleDbDataAdapter da = new OleDbDataAdapter();
        da.SelectCommand = cmd;

        DataSet ds = new DataSet();

        // fill the DataSet
        da.Fill(ds);

        Customer[] customers = new Customer[ds.Tables[0].Rows.Count];
        int ct = 0;

        // go through each row in the dataset's first table and 
        // create a new customer object
        foreach (DataRow dr in ds.Tables[0].Rows)
        {
            Customer cust = new Customer();
            cust.CustomerId = (string)dr["CustomerId"];
            cust.CompanyName = (string)dr["CompanyName"];
            cust.Address = (string)dr["Address"];
            cust.ContactName = (string)dr["ContactName"];
            cust.ContactTitle = (string)dr["ContactTitle"];
            cust.City = (string)dr["City"];
            cust.Country = (string)dr["Country"];

            customers[ct] = cust;
            ct++;
        }
        return customers;
    }

    [WebMethod]
    public Customer[] GetCustomers()
    {
        OleDbConnection conn = new OleDbConnection();
        conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\foundationaspnet\chapter8\Data\Northwind.mdb";

        OleDbCommand cmd = new OleDbCommand();
        cmd.Connection = conn;
        cmd.CommandText = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Country FROM Customers";

        OleDbCommand cmd2 = new OleDbCommand();
        cmd2.Connection = conn;
        cmd2.CommandText = "SELECT COUNT(CustomerID) FROM Customers";

        conn.Open();

        int count = (int)cmd2.ExecuteScalar();

        OleDbDataReader dr = cmd.ExecuteReader();

        Customer[] _customers = new Customer[count];
        int ct = 0;
        while (dr.Read())
        {
            Customer _cust = new Customer();
            _cust.CustomerId = dr.GetString(0);
            _cust.CompanyName = dr.GetString(1);
            _cust.ContactName = dr.GetString(2);
            _cust.ContactTitle = dr.GetString(3);
            _cust.Address = dr.GetString(4);
            _cust.City = dr.GetString(5);
            _cust.Country = dr.GetString(6);

            _customers[ct] = _cust;

            ct++;
        }
        dr.Close();
        conn.Close();

        return _customers;
    }
    
    [WebMethod]
    public bool TestAccessConnection()
    {
        OleDbConnection conn = new OleDbConnection();
        // change this to the location of the database on your system
        conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\foundationaspnet\chapter9\Data\chapter9.mdb;Persist Security Info=False";
        try
        {
            conn.Open();
            conn.Close();
            return true;
        }
        catch
        {
            return false;
        }
    }
    
}

