using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class flashvarsnav : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		/*this.EpicFlashControl1.FlashVars.Add("title1", "Microsoft");
		this.EpicFlashControl1.FlashVars.Add("title2", "Macromedia");
		this.EpicFlashControl1.FlashVars.Add("title3", "friends of ED");
		this.EpicFlashControl1.FlashVars.Add("title4", "ASP.NET");
		this.EpicFlashControl1.FlashVars.Add("title5", "epicFlashControl");
		this.EpicFlashControl1.FlashVars.Add("title6", "Visual Studio .NET");*/
        this.EpicFlashControl1.FlashVars.Add("title1", "Gray Button");
    }
}
