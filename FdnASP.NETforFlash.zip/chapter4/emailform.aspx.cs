using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

public partial class emailform2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		string msgText = "You have received a new contact submission:<br><br>";

		msgText += "<b>First Name:</b> " + Request["firstName"];
		msgText += "<b>Last Name:</b> " + Request["lastName"];
		msgText += "<b>Phone #:</b> " + Request["phoneNumber"];
		msgText += "<b>E-mail Address:</b> " + Request["emailAddress"];
		msgText += "<b>Found Us Through:</b> " + Request["found"];

		MailMessage msg = new MailMessage();
		msg.BodyFormat = MailFormat.Html;
		msg.Subject = "Flash E-mail Form Submission";
		msg.Body = msgText;
		msg.From = "ryan@rymoore.com";
		msg.To = "web@balancestudios.com";

		try
		{
			SmtpMail.SmtpServer = "127.0.0.1";
			System.Web.Mail.SmtpMail.Send(msg);
			Response.Write("success=true");
		}
		catch (Exception e2)
		{
			Response.Write("success=" + e2.Message);
		}

    }
}
