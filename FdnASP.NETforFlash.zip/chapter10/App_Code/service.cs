using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data;
using System.Data.OleDb;

/// <summary>
/// Summary description for service
/// </summary>
[WebService(Namespace = "http://www.friendsofed.com/", Name="Chapter_10_Storefront")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class service : System.Web.Services.WebService {
	string _connString;

    public service () {
		_connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\foundationaspnet\chapter10\data\store.mdb";
    }
	public struct Product
	{
		public int ProductId;
		public string ProductName;
		public string ProductDesc;
		public double ProductPrice;
		public int ProductCategory;
		public string ProductImage;
	}
	public struct ProductCategory
	{
		public int CatId;
		public string CatName;
	}

	[WebMethod]
	public Product[] GetCategoryProducts(int catId)
	{
		OleDbConnection conn = new OleDbConnection(_connString);
		OleDbCommand cmd = new OleDbCommand();
		cmd.CommandText = "SELECT * FROM Products WHERE ProductCategory=" + catId.ToString();
		cmd.Connection = conn;

		conn.Open();
		OleDbDataReader dr = cmd.ExecuteReader();

		ArrayList al = new ArrayList();
		while (dr.Read())
		{
			Product prod = new Product();
			prod.ProductId = dr.GetInt32(0);
			prod.ProductName = dr.GetString(1);
			prod.ProductDesc = dr.GetString(2);
			prod.ProductPrice = dr.GetDouble(3);
			prod.ProductCategory = dr.GetInt32(4);
			prod.ProductImage = dr.GetString(5);

			al.Add(prod);
		}

		Product[] retProd = new Product[al.Count];
		for (int x = 0; x < al.Count; x++)
		{
			retProd[x] = (Product)al[x];
		}

		return retProd;
	}

	[WebMethod]
	public ProductCategory[] GetCategories()
	{
		OleDbConnection conn = new OleDbConnection(_connString);
		OleDbCommand cmd = new OleDbCommand();
		cmd.CommandText = "SELECT CategoryId, CategoryName FROM Categories";
		cmd.Connection = conn;

		conn.Open();
		OleDbDataReader dr = cmd.ExecuteReader();

		ArrayList al = new ArrayList();
		while (dr.Read())
		{
			ProductCategory pcat = new ProductCategory();
			pcat.CatId = dr.GetInt32(0);
			pcat.CatName = dr.GetString(1);

			al.Add(pcat);
		}

		ProductCategory[] pCatRet = new ProductCategory[al.Count];
		for (int x = 0; x < al.Count; x++)
		{
			pCatRet[x] = (ProductCategory)al[x];
		}
		return pCatRet;
	}
}

