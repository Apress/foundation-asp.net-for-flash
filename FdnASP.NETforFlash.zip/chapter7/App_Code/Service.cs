using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[WebService(Namespace = "http:/www.friendsofed.com/", Description = "An ASP.NET web service created in Chapter 7 of Foundation ASP.NET for Flash!")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod(Description = "Returns the string 'Hello World'")]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod(Description = "Takes a circle's radius as a parameter and return the area of that circle")]
    public double GetArea(double radius)
    {
        return Math.Pow(radius, 2) * System.Math.PI;
    }

}
