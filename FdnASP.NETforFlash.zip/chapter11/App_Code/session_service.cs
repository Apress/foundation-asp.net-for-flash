using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;


/// <summary>
/// Summary description for session_service
/// </summary>
[WebService(Namespace = "http://www.friendsofed.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class session_service : System.Web.Services.WebService {

    public session_service () {

    }

    [WebMethod (EnableSession=true)]
    public string HelloWorld() {
        return "Hello World";
    }
	[WebMethod (EnableSession=true)]
	public int Clicker()
	{
		// if it's the first click, set "clicks" to 1
		int clicks = 1;

		if (Session["clicks"] != null)
		{
			// increment it
			clicks = ((int)Session["clicks"]) + 1;
		}
		Session["clicks"] = clicks;

		// set the flash control's Result parameter to the 
		// current number of clicks in this Session
		return (clicks);
	}
	[WebMethod(EnableSession = true)]
	public int ApplicationClicker()
	{
		// if it's the first click, set "clicks" to 1
		int clicks = 1;

		if (Application["clicks"] != null)
		{
			// increment it
			clicks = ((int)Application["clicks"]) + 1;
		}
		Application["clicks"] = clicks;

		// set the flash control's Result parameter to the 
		// current number of clicks in this Application
		return (clicks);
	}
	[WebMethod(EnableSession = true)]
	public string ValidSessionEcho(string echoString)
	{
		if (ValidateUser())
		{
			return "Success: " + echoString;
		}
		else
		{
			return "Invalid access";
		}
	}
	private bool ValidateUser()
	{
		if (Context.Request.UserHostAddress == (string)Session["flashSec"])
		{
			return true;
		}
		else
		{
			return false;
		}
	}
    
}

