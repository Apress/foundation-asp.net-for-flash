using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using FlashGateway.IO;
using System.Collections;

namespace video_blog
{
    class BlogEntries
    {
        // change this connection string if needed
        private string _connString = "Data Source=localhost;Initial Catalog=video_blog;Persist Security Info=True;User ID=sa;password=seesaw;Pooling=False";

        public bool ValidateUser(string userName, string pw)
        {
            if ((userName == "admin") && (pw == "flash"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string InsertBlogPost(string title, string body, DateTime postDate, string video)
        {
            SqlConnection conn = new SqlConnection(_connString);
            SqlCommand cmd = new SqlCommand();
            // use the InsertBlogPost stored procedure
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "InsertBlogPost";
            cmd.Connection = conn;
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@body", body);
            cmd.Parameters.AddWithValue("@video", video);
            cmd.Parameters.AddWithValue("@post_date", postDate);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return "success";
            }
            catch (Exception e)
            {
                return e.ToString() ;
            }
        }
        public bool DeleteBlogPost(int bpid)
        {
            SqlConnection conn = new SqlConnection(_connString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteBlogPost";
            cmd.Parameters.AddWithValue("@id", bpid);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateBlogPost(int bpid, string title, string body, string video, DateTime postDate)
        {
            SqlConnection conn = new SqlConnection(_connString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "EditBlogPost";
            cmd.Parameters.AddWithValue("@id", bpid);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@body", body);
            cmd.Parameters.AddWithValue("@video", video);
            cmd.Parameters.AddWithValue("@post_date", postDate);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public ASObject[] GetPosts()
        {
            SqlConnection conn = new SqlConnection(_connString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "GetPosts";
            cmd.Connection = conn;

            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            ArrayList al = new ArrayList();
            while (dr.Read())
            {
                ASObject aso = new ASObject();
                aso.Add("item_id", dr.GetInt32(0));
                aso.Add("item_title", dr.GetString(1));
                aso.Add("item_body", dr.GetString(2));
                aso.Add("item_video", dr.GetString(3));
                aso.Add("post_date", dr.GetDateTime(4));

                al.Add(aso);
            }
            dr.Close();
            conn.Close();

            ASObject[] rets = new ASObject[al.Count];
            for (int x = 0; x < al.Count; x++)
            {
                rets[x] = (ASObject)al[x];
            }

            return rets;
        }
    }
}