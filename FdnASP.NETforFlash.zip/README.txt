Foundation ASP.NET for Flash

Installation Notes:
 - Remember to change the port number and URLs of the page calls within Flash to correspond with your ASP.NET projects.
 - Chapter 8 requires you to insert your Google Key into the Application.as file. 
 - A script resides in chapter13/SQLDATA which will create the database scema necessary to run the chapter 13 example. 
 - Also remember to change the location of the SQL and Access connection strings in chapters 9+

Support for these examples will be (is) avaialble at:

http://www.flashasp.net

Have Fun!
