using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service () {

    }

	[WebMethod]
	public com.google.api.GoogleSearchResult GoogleSearch(string key, string query, int start, int results, bool filter, string restrict, bool safe, string languageRestrict, string ie, string oe)
	{
        com.google.api.GoogleSearchService serv = new com.google.api.GoogleSearchService();
        com.google.api.GoogleSearchResult sres = serv.doGoogleSearch(key, query, start, results, filter, restrict, safe, languageRestrict, ie, oe);
        return sres;
	}

	[WebMethod]
	public string GoogleSpell(string key, string phrase)
	{
        com.google.api.GoogleSearchService serv = new com.google.api.GoogleSearchService();
        return serv.doSpellingSuggestion(key, phrase);
	}
    
}
