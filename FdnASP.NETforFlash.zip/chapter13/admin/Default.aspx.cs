using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if (Page.Request.Files.Count > 0)
		{
			string fn = Page.Request.Files[0].FileName;
			try
			{
				Page.Request.Files[0].SaveAs(Server.MapPath("~\\uploads\\" + fn));
			}
			catch (Exception e3)
			{
				string p = e3.ToString();
			}
		}
    }
}
