using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class navbar2 : System.Web.UI.Page
{
	void Page_Load(object sender, EventArgs e)
	{
		string outputString;
		outputString = MakeLoadVar("title1", "Home");
		outputString += MakeLoadVar("title2", "Photos");
		outputString += MakeLoadVar("title3", "Videos");
		outputString += MakeLoadVar("title4", "Links");
		outputString += MakeLoadVar("title5", "About");
		outputString += MakeLoadVar("title6", "Contact");

		Response.Write(outputString);
	}

	private string MakeLoadVar(string name, string value)
	{
		return "&" + Server.HtmlEncode(name) + "=" + Server.HtmlEncode(value);
	}
}
