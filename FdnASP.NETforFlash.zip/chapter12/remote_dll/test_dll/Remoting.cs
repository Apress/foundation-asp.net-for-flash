using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace test_dll
{
	class Remoting
	{
		public string EchoString(string orig)
		{
			return "Flash Remoting " + orig;
		}

        public string SendObject(FlashGateway.IO.ASObject aso)
        {
            string ret = "<b>" + aso.Keys.Count.ToString() + " Properties Found</b><br><br>";

            // create new string arrays
            string[] vals = new string[aso.Keys.Count];
            string[] keys = new string[aso.Keys.Count];

            // copy the keys and values to the string arrays
            aso.Keys.CopyTo(keys, 0);
            aso.Values.CopyTo(vals, 0);            

            // go through each key/value pair and add it to the string
            for (int x = 0; x < keys.Length; x++)
            {
                ret += "<b>" + keys.GetValue(x).ToString() + ":</b> " + vals.GetValue(x).ToString();
                ret += "<br>";
            }

            return ret;
        }

		public DataTable GetCategories()
		{
			string _connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\foundationaspnet\chapter9\data\Northwind.mdb";
			OleDbConnection conn = new OleDbConnection(_connString);
			OleDbCommand cmd = new OleDbCommand();
			cmd.CommandText = "SELECT CategoryID, CategoryName, Description FROM Categories";
			cmd.Connection = conn;

			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = cmd;

			DataSet ds = new DataSet();
			da.Fill(ds);

			return ds.Tables[0];
		}
		public FlashGateway.IO.ASObject[] GetCategoriesAS()
		{
            // remember to change this connection string
			string _connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\foundationaspnet\chapter9\data\Northwind.mdb";
			OleDbConnection conn = new OleDbConnection(_connString);
			OleDbCommand cmd = new OleDbCommand();
			cmd.CommandText = "SELECT CategoryID, CategoryName, Description FROM Categories";
			cmd.Connection = conn;

			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = cmd;

			DataSet ds = new DataSet();
			da.Fill(ds);

			FlashGateway.IO.ASObject[] ret = new FlashGateway.IO.ASObject[ds.Tables[0].Rows.Count];
			for (int x = 0; x < ds.Tables[0].Rows.Count; x++)
			{
				DataRow dr = ds.Tables[0].Rows[x];

				FlashGateway.IO.ASObject aso = new FlashGateway.IO.ASObject();
				aso.ASType = "Category";

				aso.Add("CategoryID", (int)dr["CategoryID"]);
				aso.Add("CategoryName", (string)dr["CategoryName"]);
				aso.Add("Description", (string)dr["Description"]);

				ret[x] = aso;
				
			}
			return ret;
		}
	}
}