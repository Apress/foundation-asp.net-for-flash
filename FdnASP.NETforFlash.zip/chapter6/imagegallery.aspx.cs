using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.IO;

public partial class imagegallery_aspx
{
	void Page_Load(object sender, EventArgs e)
	{
		XmlTextWriter xmlWriter = new XmlTextWriter(Response.OutputStream, System.Text.Encoding.UTF8);
		xmlWriter.WriteStartDocument();
		xmlWriter.WriteStartElement("gallery");

		System.IO.File.
		string[] dirs = Directory.GetDirectories(Server.MapPath("~/images"));
		foreach (string dirname in dirs)
		{
			xmlWriter.WriteStartElement("folder");
			xmlWriter.WriteAttributeString("name", dirname.Substring(dirname.LastIndexOf("\\") + 1));

			string[] files = Directory.GetFiles(dirname, "*.jpg");
			foreach (string filename in files)
			{
				if (filename.IndexOf("_tmb") == -1)
				{
					string thumb = filename.Replace(".", "_tmb.");
					if (!System.IO.File.Exists(thumb))
					{
						System.Drawing.Image img = System.Drawing.Image.FromFile(filename);
						img = img.GetThumbnailImage(100, 100, this.ThumbnailCallback, IntPtr.Zero);
						img.Save(thumb, System.Drawing.Imaging.ImageFormat.Jpeg);
					}

					// add the file to the XML document
					string shortFilename = filename.Substring(filename.LastIndexOf("\\") + 1);
					xmlWriter.WriteElementString("image", shortFilename);
				}
			}
			xmlWriter.WriteEndElement();
		}

		xmlWriter.WriteEndElement();
		xmlWriter.WriteEndDocument();
		xmlWriter.Close();
	}
	public bool ThumbnailCallback()
	{
		return false;
	}
}
